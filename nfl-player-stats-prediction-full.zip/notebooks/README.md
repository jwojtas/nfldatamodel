# Notebooks

This folder contains example notebook templates. You can copy-paste the cells from the project README or the earlier messages into new notebooks.

Suggested notebooks:
- build_features.ipynb
- train_models.ipynb
- predict_next_games.ipynb

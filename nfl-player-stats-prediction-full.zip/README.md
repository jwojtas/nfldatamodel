# NFL Player Stats Prediction (nflverse-backed)

This repository produces player-stat predictions for upcoming NFL games using nflverse (nflfastR) data sources.
It includes:
- Data loading from nflverse parquet releases (preferred) or via optional Python helpers (`nflreadpy`, `nfl_data_py`).
- Feature engineering (rolling features, opponent joins, environment).
- Model training (XGBoost regression for yards, Poisson for counts, Logistic for binary events).
- Model prediction for next-game rows.
- Dockerfile for containerized inference/training.

## Quickstart

1. Create conda env:
```
conda env create -f environment.yml
conda activate nfl-stats
```

2. Download data (example):
```py
python -c "from src.data_loading import load_player_stats; df = load_player_stats(2023); print(df.shape)"
```

3. Build processed game logs and train models:
```
python -m src.model_training --logs_csv data/processed/player_game_logs.csv --targets rec_yards,receptions,targets
```

4. Predict:
```
python -m src.model_predict --models_dir models --next_games_csv data/processed/next_games.csv --out predictions.csv
```

## Notes

- The loader will attempt `nflreadpy` / `nfl_data_py` first; if not available it will download release parquet files directly from nflverse GitHub releases.
- For best results, run data download once and keep `data/raw/` and `data/processed/` persisted.
